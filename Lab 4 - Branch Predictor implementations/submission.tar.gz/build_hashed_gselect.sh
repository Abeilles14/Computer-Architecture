./compile_champsim.sh hashed_gselect no no no no lru 4
