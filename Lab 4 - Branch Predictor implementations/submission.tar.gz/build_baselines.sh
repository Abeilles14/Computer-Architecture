./compile_champsim.sh hashed_perceptron no no no no lru 4
./compile_champsim.sh perceptron no no no no lru 4
