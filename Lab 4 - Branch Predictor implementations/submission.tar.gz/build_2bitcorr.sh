./compile_champsim.sh 2bitcorr no no no no lru 4
