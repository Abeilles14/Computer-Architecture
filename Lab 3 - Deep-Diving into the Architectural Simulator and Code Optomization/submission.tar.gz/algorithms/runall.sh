#!/bin/bash
./assignment3.bin 0 1000
./assignment3.bin 1 1000
./assignment3.bin 2 1000
