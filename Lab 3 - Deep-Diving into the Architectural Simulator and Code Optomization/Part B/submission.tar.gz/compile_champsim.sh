#!/bin/bash
./config.sh champsim_config.json
make