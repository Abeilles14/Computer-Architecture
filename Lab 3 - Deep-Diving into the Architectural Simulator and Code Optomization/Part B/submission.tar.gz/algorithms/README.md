Read this carefully
1. EDIT ONLY matmul_opt1.c, matmul_opt1.h, matmul_opt2.c, matmul_opt2.h, matmul_opt3.c, and matmul_opt3.h.
2. DO NOT EDIT ANY OTHER FILES
3. DO NOT WRITE PRINTF, COUT, etc. IN ANY FILE.
4. IF YOU BREAK THESE RULES AND YOUR SUBMISSION DOES NOT ADHER TO THIS --> YOU WILL GET 0 MARKS.

Compile this folder with the following command:
$ make

Run the matrix multiplication codes with the following command:
$ bash runall.sh

You could check if your code has passed or not in the output directory