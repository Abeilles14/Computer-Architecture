./compile_champsim.sh hashed_perceptron no no no no lru 4
./compile_champsim.sh hashed_perceptron no no no no srrip 4
./compile_champsim.sh hashed_perceptron no no no no drrip 4
./compile_champsim.sh hashed_perceptron no no no no ship 4
./compile_champsim.sh hashed_perceptron no no no no hawkeye 4